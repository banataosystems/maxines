-- Source-backed catalog only. The supplied blueprint references 41 raw images, but visibly specifies
-- 13 purchasable SKU/price records. The missing items, stock, size variants, and fiat settlement prices
-- are deliberately NOT invented. Source-derived products remain checkout_enabled=false until verified.

insert into public.products (sku, name, category, display_price, display_currency, tag, description, image_url, source_verified, checkout_enabled, active, sort_order)
values
('PRT-001','Palm Resort','Statement Prints',45,'TON','Palm Resort','Statement print top documented in the supplied Atelier blueprint.','/products/prt-001.jpg',true,false,true,10),
('PRT-002','Leopard Box','Statement Prints',35,'TON','Leopard Box','Leopard statement print documented in the supplied Atelier blueprint.','/products/prt-002.jpg',true,false,true,20),
('PRT-003','Wrap Silk','Statement Prints',55,'TON','Wrap Silk','Wrap-style silk piece documented in the supplied Atelier blueprint.','/products/prt-003.jpg',true,false,true,30),
('OUT-012','Chartreuse Military Cut','Elevated Outerwear',85,'TON','Brass hardware','Chartreuse military cut with brass hardware.','/products/out-012.jpg',true,false,true,40),
('OUT-014','Heritage Plaid','Elevated Outerwear',95,'TON','Velvet shoulder accent','Heritage plaid jacket with velvet shoulder accent.','/products/out-014.jpg',true,false,true,50),
('GRF-101','Vintage Eagle Lace','Graphic & Edgy',40,'TON','Vintage Eagle Lace','Graphic editorial tee documented in the supplied Atelier blueprint.','/products/grf-101.jpg',true,false,true,60),
('GRF-102','Technical Mesh','Graphic & Edgy',30,'TON','Technical Mesh','Technical mesh top documented in the supplied Atelier blueprint.','/products/grf-102.jpg',true,false,true,70),
('GRF-103','Slogan Crop','Graphic & Edgy',25,'TON','Slogan Crop','Cropped slogan tee documented in the supplied Atelier blueprint.','/products/grf-103.jpg',true,false,true,80),
('BSC-04','Alabaster Cream','Editorial Basics',20,'TON','Alabaster Cream','Editorial basic in alabaster cream.','/products/bsc-04.jpg',true,false,true,90),
('BSC-05','Optic White','Editorial Basics',18,'TON','Optic White','Editorial basic in optic white.','/products/bsc-05.jpg',true,false,true,100),
('BSC-06','Deep Burgundy','Editorial Basics',22,'TON','Deep Burgundy','Editorial basic in deep burgundy.','/products/bsc-06.jpg',true,false,true,110),
('SHRT-88','Typographic Back Print','Shirts & Blouses',50,'TON','Typographic Back Print','White shirt with typographic back print.','/products/shrt-88.jpg',true,false,true,120),
('SHRT-89','Botanical Contrast Collar','Shirts & Blouses',45,'TON','Botanical Contrast Collar','Botanical shirt with contrast collar.','/products/shrt-89.jpg',true,false,true,130)
on conflict (sku) do update set
  name = excluded.name,
  category = excluded.category,
  display_price = excluded.display_price,
  display_currency = excluded.display_currency,
  tag = excluded.tag,
  description = excluded.description,
  image_url = excluded.image_url,
  source_verified = excluded.source_verified,
  updated_at = now();

-- Before live checkout for a SKU, add verified variants + stock and a provider settlement price.
-- Example template only (do not run with invented values):
-- insert into public.product_variants(product_id,size,stock)
-- select id,'M',3 from public.products where sku='PRT-001';
-- insert into public.payment_prices(product_id,currency,unit_amount)
-- select id,'PHP',250000 from public.products where sku='PRT-001';
-- update public.products set checkout_enabled=true where sku='PRT-001';
